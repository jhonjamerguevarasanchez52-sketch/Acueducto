import { useEffect, useState } from 'react'
import {
  AlertTriangle,
  ArrowUpRight,
  BellRing,
  CheckCircle2,
  CreditCard,
  Download,
  FileText,
  KeyRound,
  Menu,
  Printer,
  Search,
  UserRound,
  UserRoundPlus,
} from 'lucide-react'
import Sidebar from './components/Sidebar.jsx'
import AuthScreen from './features/auth/AuthScreen.jsx'
import ForcedPasswordChange from './features/auth/ForcedPasswordChange.jsx'
import exportTreasuryWorkbookFile from './features/reports/exportTreasuryWorkbook.js'
import { imprimirFactura } from './features/invoices/printInvoice.js'
import SectionViews from './features/sections/SectionViews.jsx'
import { quickActions, resourceEndpointBySection, paginatedEndpoints, MAX_BULK_USERS, MAX_USER_FILE_SIZE_BYTES, operationDefinitions, roleColors } from './config/adminConfig.js'
import { apiRequest, apiRequestAll, clearToken, endpoints, getToken, login } from './services/api.js'

const fetchResource = (endpointName) => (
  paginatedEndpoints.has(endpointName)
    ? apiRequestAll(endpoints[endpointName])
    : apiRequest(endpoints[endpointName])
)
import { formatMoney, formatDate, formatInvoiceNumber } from './utils/formatters.js'
import { parseUsersCsv, parseUsersExcel } from './utils/usersCsv.js'
import { diaColombia, esPagoPendiente, fechaRecaudo, requiereAccion } from './utils/pagos.js'
import hidroAppLogo from './assets/hidroapp-logo.png'

function App() {
  const [activeSection, setActiveSection] = useState('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [sessionStatus, setSessionStatus] = useState(getToken() ? 'checking' : 'signed-out')
  const [profile, setProfile] = useState(null)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [recoveryCode, setRecoveryCode] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmNewPassword, setConfirmNewPassword] = useState('')
  const [authMode, setAuthMode] = useState('login')
  const [searchQuery, setSearchQuery] = useState('')
  const [authError, setAuthError] = useState('')
  const [authNotice, setAuthNotice] = useState('')
  const [isLoggingIn, setIsLoggingIn] = useState(false)
  const [sectionData, setSectionData] = useState({})
  const [sectionErrors, setSectionErrors] = useState({})
  const [loadingSections, setLoadingSections] = useState({})
  const [createUserOpen, setCreateUserOpen] = useState(false)
  const [newUser, setNewUser] = useState({ nombre: '', apellido: '', correo: '', cedula: '', rol: 'usuario', telefono: '', numero_lote: '', direccion: '', zona: '' })
  const [createUserError, setCreateUserError] = useState('')
  const [createdTemporaryPassword, setCreatedTemporaryPassword] = useState('')
  const [createdUserEmailSent, setCreatedUserEmailSent] = useState(false)
  const [isCreatingUser, setIsCreatingUser] = useState(false)
  const [profileOpen, setProfileOpen] = useState(false)
  const [profileForm, setProfileForm] = useState({})
  const [profileError, setProfileError] = useState('')
  const [profileMessage, setProfileMessage] = useState('')
  const [isSavingProfile, setIsSavingProfile] = useState(false)
  const [currentProfilePassword, setCurrentProfilePassword] = useState('')
  const [newProfilePassword, setNewProfilePassword] = useState('')
  const [confirmProfilePassword, setConfirmProfilePassword] = useState('')
  const [passwordError, setPasswordError] = useState('')
  const [passwordMessage, setPasswordMessage] = useState('')
  const [isChangingProfilePassword, setIsChangingProfilePassword] = useState(false)
  const [bulkUserOpen, setBulkUserOpen] = useState(false)
  const [bulkUsers, setBulkUsers] = useState([])
  const [bulkUserResults, setBulkUserResults] = useState([])
  const [bulkUserError, setBulkUserError] = useState('')
  const [bulkProgress, setBulkProgress] = useState({ completed: 0, total: 0 })
  const [isImportingUsers, setIsImportingUsers] = useState(false)
  const [operationType, setOperationType] = useState('')
  const [operationItem, setOperationItem] = useState(null)
  const [operationForm, setOperationForm] = useState({})
  const [operationError, setOperationError] = useState('')
  const [operationPending, setOperationPending] = useState(false)
  const [zones, setZones] = useState([])
  const [invoicePreview, setInvoicePreview] = useState(null)
  const [actionMessage, setActionMessage] = useState('')
  const [actionError, setActionError] = useState('')
  const now = new Date()
  const [reportFrom, setReportFrom] = useState(`${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`)
  const [reportTo, setReportTo] = useState(`${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`)

  const applyReportPreset = (preset) => {
    const current = new Date()
    const year = current.getFullYear()
    const month = current.getMonth()
    const dateValue = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
    let start
    let end
    if (preset === 'year') {
      start = new Date(year, 0, 1)
      end = new Date(year, 11, 31)
    } else if (preset === 'semester') {
      const semesterStartMonth = month < 6 ? 0 : 6
      start = new Date(year, semesterStartMonth, 1)
      end = new Date(year, semesterStartMonth + 6, 0)
    } else {
      start = new Date(year, month, 1)
      end = new Date(year, month + 1, 0)
    }
    setReportFrom(dateValue(start))
    setReportTo(dateValue(end))
  }

  const filterRows = (rows) => {
    const query = searchQuery.trim().toLocaleLowerCase('es')
    if (!query) return rows
    return rows.filter((row) => Object.values(row).some((value) => (
      String(value ?? '').toLocaleLowerCase('es').includes(query)
    )))
  }

  useEffect(() => {
    const handleExpiredSession = () => {
      clearToken()
      setProfile(null)
      setSectionData({})
      setSessionStatus('signed-out')
      setAuthError('Tu sesión expiró. Inicia sesión de nuevo para continuar.')
    }
    window.addEventListener('hidro-session-expired', handleExpiredSession)
    if (!getToken()) return () => window.removeEventListener('hidro-session-expired', handleExpiredSession)

    apiRequest(endpoints.profile)
      .then((currentProfile) => {
        if (currentProfile.rol !== 'administrador') {
          throw new Error('Esta cuenta no tiene permisos de administrador')
        }
        setProfile(currentProfile)
        setSessionStatus(currentProfile.debe_cambiar_password ? 'must-change-password' : 'authenticated')
      })
      .catch((error) => {
        clearToken()
        setAuthError(error.message || 'La sesión expiró. Inicia sesión de nuevo.')
        setSessionStatus('signed-out')
      })
    return () => window.removeEventListener('hidro-session-expired', handleExpiredSession)
  }, [])

  useEffect(() => {
    if (sessionStatus !== 'authenticated' || activeSection !== 'dashboard') return

    let cancelled = false
    Promise.all(Object.entries(resourceEndpointBySection).filter(([section]) => !['eliminados', 'paz-y-salvo'].includes(section)).map(async ([section, endpointName]) => {
      try {
        const data = await fetchResource(endpointName)
        return { section, data: Array.isArray(data) ? data : [], error: '' }
      } catch (error) {
        return { section, data: [], error: error.message || 'No fue posible cargar los datos' }
      }
    })).then((results) => {
      if (cancelled) return
      setSectionData((current) => ({
        ...current,
        ...Object.fromEntries(results.map(({ section, data }) => [section, data])),
      }))
      setSectionErrors((current) => ({
        ...current,
        ...Object.fromEntries(results.map(({ section, error }) => [section, error])),
      }))
    })

    return () => { cancelled = true }
  }, [activeSection, sessionStatus])

  const loadSection = async (section) => {
    const endpointName = resourceEndpointBySection[section]
    if (!endpointName) return

    setLoadingSections((current) => ({ ...current, [section]: true }))
    setSectionErrors((current) => ({ ...current, [section]: '' }))
    try {
      const data = await fetchResource(endpointName)
      setSectionData((current) => ({ ...current, [section]: Array.isArray(data) ? data : [] }))
    } catch (error) {
      setSectionErrors((current) => ({ ...current, [section]: error.message || 'No fue posible cargar los datos' }))
    } finally {
      setLoadingSections((current) => ({ ...current, [section]: false }))
    }
  }

  const ensureUsersLoaded = async () => {
    if (sessionStatus !== 'authenticated') return
    const usersLoaded = (sectionData.usuarios || []).length > 0
    if (usersLoaded || sectionErrors.usuarios) return
    await loadSection('usuarios')
  }

  const handleNavigate = (section) => {
    setActiveSection(section)
    setSearchQuery('')
    loadSection(section)
    if (section === 'facturas' || section === 'pagos') void ensureUsersLoaded()

    if (section === 'paz-y-salvo') void ensureUsersLoaded()

    if (section === 'cortes') void loadSection('cortesProgramados')

    if (section === 'reportes') {
      void Promise.all(['usuarios', 'facturas', 'pagos'].map((name) => loadSection(name)))
    }
  }

  const handleCreateUser = async (event) => {
    event.preventDefault()
    setIsCreatingUser(true)
    setCreateUserError('')
    try {
      // Los campos opcionales vacíos no se envían.
      const body = Object.fromEntries(Object.entries(newUser).filter(([, valor]) => String(valor).trim() !== ''))
      const result = await apiRequest(endpoints.adminUsers, {
        method: 'POST',
        body,
      })
      setCreatedTemporaryPassword(result.passwordTemporal || '')
      setCreatedUserEmailSent(result.correoEnviado === true)
      await loadSection('usuarios')
    } catch (error) {
      setCreateUserError(error.message || 'No fue posible crear el usuario')
    } finally {
      setIsCreatingUser(false)
    }
  }

  const openBulkUserImport = () => {
    setBulkUsers([])
    setBulkUserResults([])
    setBulkUserError('')
    setBulkProgress({ completed: 0, total: 0 })
    setBulkUserOpen(true)
  }

  const handleBulkFileChange = async (event) => {
    const file = event.target.files?.[0]
    event.target.value = ''
    setBulkUsers([])
    setBulkUserResults([])
    setBulkUserError('')

    if (!file) return
    const extension = file.name.split('.').pop()?.toLowerCase()
    if (!['csv', 'xlsx'].includes(extension)) {
      setBulkUserError('Selecciona un archivo CSV o Excel (.xlsx).')
      return
    }
    if (file.size > MAX_USER_FILE_SIZE_BYTES) {
      setBulkUserError('El archivo supera el tamaño máximo de 5 MB.')
      return
    }

    try {
      const rows = extension === 'csv'
        ? parseUsersCsv(await file.text())
        : await parseUsersExcel(file)
      if (rows.length > MAX_BULK_USERS) {
        setBulkUserError(`El archivo supera el máximo de ${MAX_BULK_USERS} usuarios. Divídelo en varios archivos.`)
        return
      }
      setBulkUsers(rows)
    } catch (error) {
      setBulkUserError(error.message || 'No fue posible leer el archivo.')
    }
  }

  const handleDownloadBulkErrors = () => {
    const errors = bulkUserResults.filter((user) => user.status === 'error')
    if (errors.length === 0) return

    const quote = (value) => {
      const text = String(value ?? '')
      const safeText = /^[\s]*[=+\-@]/.test(text) ? `'${text}` : text
      return `"${safeText.replaceAll('"', '""')}"`
    }
    const lines = [
      ['nombre', 'apellido', 'correo', 'cedula', 'rol', 'error'],
      ...errors.map((user) => [user.nombre, user.apellido, user.correo, user.cedula, user.rol, user.error || user.message]),
    ]
    const csv = lines.map((line) => line.map(quote).join(',')).join('\r\n')
    const file = new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8' })
    const url = URL.createObjectURL(file)
    const link = document.createElement('a')
    link.href = url
    link.download = `usuarios-con-errores-${new Date().toISOString().slice(0, 10)}.csv`
    link.click()
    URL.revokeObjectURL(url)
  }

  const handleBulkUserImport = async (event) => {
    event.preventDefault()
    const validUsers = bulkUsers.filter((user) => !user.error)
    if (validUsers.length === 0) return

    setIsImportingUsers(true)
    setBulkUserError('')
    setBulkProgress({ completed: 0, total: validUsers.length })
    setBulkUserResults(bulkUsers.map((user) => ({
      ...user,
      status: user.error ? 'error' : 'pending',
      message: user.error || 'Pendiente',
    })))

    let completed = 0
    for (const user of validUsers) {
      let result
      try {
        const response = await apiRequest(endpoints.adminUsers, {
          method: 'POST',
          body: {
            nombre: user.nombre,
            apellido: user.apellido,
            correo: user.correo,
            cedula: user.cedula,
            rol: user.rol,
          },
        })
        result = {
          ...user,
          status: response.correoEnviado === false ? 'warning' : 'success',
          message: response.correoEnviado === false
            ? `${response.message || 'Cuenta creada, pero el correo falló.'} Contraseña temporal: ${response.passwordTemporal || 'no disponible'}`
            : response.message || 'Cuenta creada.',
        }
      } catch (error) {
        result = { ...user, status: 'error', message: error.message || 'No fue posible crear la cuenta.' }
      }

      completed += 1
      setBulkProgress({ completed, total: validUsers.length })
      setBulkUserResults((current) => current.map((row) => (
        row.line === user.line ? result : row
      )))
    }

    await loadSection('usuarios')
    setIsImportingUsers(false)
  }

  const downloadFile = (file, filename) => {
    const url = URL.createObjectURL(file)
    const link = document.createElement('a')
    link.href = url
    link.download = filename
    link.click()
    window.setTimeout(() => URL.revokeObjectURL(url), 1000)
  }

  const handleDownloadUsersTemplate = async (format) => {
    try {
      if (format === 'xlsx') {
        const ExcelJS = (await import('exceljs')).default
        const workbook = new ExcelJS.Workbook()
        const sheet = workbook.addWorksheet('Usuarios')
        sheet.columns = [
          { header: 'nombre', key: 'nombre', width: 20 },
          { header: 'apellido', key: 'apellido', width: 20 },
          { header: 'correo', key: 'correo', width: 32 },
          { header: 'cedula', key: 'cedula', width: 18 },
          { header: 'rol', key: 'rol', width: 18 },
        ]
        sheet.addRow({ nombre: 'Ana', apellido: 'Lopez', correo: 'ana@ejemplo.com', cedula: '1234567890', rol: 'usuario' })
        sheet.views = [{ state: 'frozen', ySplit: 1 }]
        sheet.autoFilter = 'A1:E1'
        const buffer = await workbook.xlsx.writeBuffer()
        downloadFile(new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), 'plantilla-usuarios.xlsx')
      } else {
        const content = '\uFEFFnombre,apellido,correo,cedula,rol\r\nAna,Lopez,ana@ejemplo.com,1234567890,usuario\r\n'
        downloadFile(new Blob([content], { type: 'text/csv;charset=utf-8' }), 'plantilla-usuarios.csv')
      }
      setBulkUserError('')
    } catch (error) {
      setBulkUserError(error.message || 'No fue posible generar la plantilla.')
    }
  }

  const openCreateUser = () => {
    setCreateUserError('')
    setCreatedTemporaryPassword('')
    setCreatedUserEmailSent(false)
    setNewUser({ nombre: '', apellido: '', correo: '', cedula: '', rol: 'usuario', telefono: '', numero_lote: '', direccion: '', zona: '' })
    setCreateUserOpen(true)
  }

  const openOperation = async (type, item = null) => {
    const definition = operationDefinitions[type]
    if (!definition) return

    if (definition.fields.some((field) => field.type === 'user' || field.type === 'recipient')) {
      await ensureUsersLoaded()
    }
    if (definition.fields.some((field) => field.type === 'zona')) {
      try {
        const zonas = await apiRequest(endpoints.zonas)
        setZones(Array.isArray(zonas) ? zonas : [])
      } catch {
        // Sin la lista igual se puede anunciar un corte para todo el acueducto.
        setZones([])
      }
    }

    setOperationType(type)
    setOperationItem(item)
    setOperationError('')
    setOperationForm(Object.fromEntries(definition.fields.map((field) => [
      field.name,
      field.type === 'date' && item?.[field.name]
        ? String(item[field.name]).slice(0, 10)
        : item?.[field.name] ?? field.defaultValue ?? '',
    ])))
  }

  const handleOperationSubmit = async (event) => {
    event.preventDefault()
    const definition = operationDefinitions[operationType]
    if (operationType === 'facturacionMensual') {
      const confirmar = window.confirm(
        `Se generarán facturas de servicio con la tarifa residencial vigente para los usuarios activos sin factura del periodo ${operationForm.periodo}. ¿Continuar?`,
      )
      if (!confirmar) return
    }
    if (operationType === 'facturaExtraordinaria' && operationForm.perfil_ids === 'todos') {
      // Igual que el backend: se factura a todas las cuentas activas, también
      // administradores y fontanero (también son suscriptores del acueducto).
      const cantidad = users.filter((user) => user.activo).length
      const total = cantidad * Number(operationForm.valor_total || 0)
      const confirmar = window.confirm(
        `Se generará una factura extraordinaria por ${formatMoney(operationForm.valor_total)} a cada una de las ${cantidad} cuentas activas. Total: ${formatMoney(total)}. Concepto: ${operationForm.concepto}. ¿Continuar?`,
      )
      if (!confirmar) return
    }
    if (operationType === 'registrarPago') {
      const confirmar = window.confirm(
        `¿Registrar el pago de ${formatMoney(operationItem?.valor_total)} (${operationForm.metodo}) para la factura ${formatInvoiceNumber(operationItem)}? La factura quedará pagada.`,
      )
      if (!confirmar) return
    }
    const esEdicion = definition.method === 'PUT'
    // En una edición, vaciar un campo de texto o fecha opcional significa
    // borrarlo (null); al crear, un campo vacío simplemente no se envía.
    const sePuedeBorrar = (field) => esEdicion && !field.required
      && !['number', 'select', 'user', 'recipient', 'checkbox'].includes(field.type)
    const body = Object.fromEntries(definition.fields
      .filter((field) => field.type !== 'recipient'
        && (operationForm[field.name] !== '' || sePuedeBorrar(field)))
      .map((field) => {
        if (operationForm[field.name] === '') return [field.name, null]
        const valor = operationForm[field.name]
        if (field.type === 'number') return [field.name, Number(valor)]
        // datetime-local llega sin zona horaria: se interpreta en la hora del
        // navegador del administrador (Colombia) y se envía en ISO.
        if (field.type === 'datetime-local') return [field.name, new Date(valor).toISOString()]
        return [field.name, valor]
      }))
    if (operationType === 'facturaExtraordinaria' && operationForm.perfil_ids !== 'todos') {
      body.perfil_ids = [operationForm.perfil_ids]
    }
    // Operaciones sobre un registro que lo envían en el cuerpo (p. ej. factura_id).
    if (definition.itemIdField && operationItem) {
      body[definition.itemIdField] = operationItem.id
    }
    const suffix = operationType === 'editarUsuario' || operationType === 'editarTarifa' || operationType === 'editarFactura'
      ? `/${operationItem.id}`
      : ''

    setOperationPending(true)
    setOperationError('')
    setActionMessage('')
    setActionError('')
    try {
      const result = await apiRequest(`${definition.endpoint}${suffix}`, {
        method: definition.method,
        body,
      })
      const resumenCorreo = result.correos_enviados === undefined
        ? ''
        : ` Correos enviados: ${result.correos_enviados}; fallidos: ${result.correos_fallidos}.`
      setActionMessage(`${result.message || 'Cambios guardados.'}${resumenCorreo}`)
      setOperationType('')
      await loadSection(definition.section)
    } catch (error) {
      setOperationError(error.message || 'No fue posible completar la operación.')
    } finally {
      setOperationPending(false)
    }
  }

  const performAction = async (section, path, method, body, confirmation) => {
    if (confirmation && !window.confirm(confirmation)) return
    setActionMessage('')
    setActionError('')
    try {
      const result = await apiRequest(path, { method, body })
      setActionMessage(result.message || 'Operación completada.')
      await loadSection(section)
    } catch (error) {
      // Un usuario con facturas o pagos no se borra (es la contabilidad):
      // el backend sugiere desactivarlo y se ofrece hacerlo en el momento.
      if (error.data?.puedeDesactivar && path.startsWith(`${endpoints.adminUsers}/`)
        && window.confirm(`${error.message}\n\n¿Quieres desactivarlo ahora?`)) {
        return performAction(section, `${path}/estado`, 'PUT', { activo: false })
      }
      setActionError(error.message || 'No fue posible completar la operación.')
    }
  }

  const openInvoicePreview = async (invoice) => {
    await ensureUsersLoaded()
    setInvoicePreview(invoice)
  }

  const handleDownloadInvoice = () => {
    const abierta = imprimirFactura(
      document.getElementById('invoice-document'),
      formatInvoiceNumber(invoicePreview),
    )
    setActionError(abierta ? '' : 'Permite las ventanas emergentes para descargar la factura.')
  }

  const handleLogin = async (event) => {
    event.preventDefault()
    setIsLoggingIn(true)
    setAuthError('')
    setAuthNotice('')

    try {
      // El rol se valida después de entrar: no existe una ruta pública para
      // preguntar si un correo es de administrador (permitía enumerarlos).
      await login(email.trim().toLowerCase(), password)
      const currentProfile = await apiRequest(endpoints.profile)
      if (currentProfile.rol !== 'administrador') {
        throw new Error('Esta cuenta no tiene permisos de administrador')
      }
      setProfile(currentProfile)
      // Con la contraseña temporal el servidor solo deja cambiarla.
      if (currentProfile.debe_cambiar_password) setCurrentProfilePassword(password)
      setSessionStatus(currentProfile.debe_cambiar_password ? 'must-change-password' : 'authenticated')
      setPassword('')
    } catch (error) {
      clearToken()
      setAuthError(error.message || 'No fue posible iniciar sesión')
    } finally {
      setIsLoggingIn(false)
    }
  }

  const openProfile = () => {
    setProfileForm({
      nombre: profile?.nombre || '',
      apellido: profile?.apellido || '',
      telefono: profile?.telefono || '',
      numero_lote: profile?.numero_lote || '',
      direccion: profile?.direccion || '',
      ocupacion: profile?.ocupacion || '',
      zona: profile?.zona || '',
    })
    setProfileError('')
    setProfileMessage('')
    setPasswordError('')
    setPasswordMessage('')
    setCurrentProfilePassword('')
    setNewProfilePassword('')
    setConfirmProfilePassword('')
    setProfileOpen(true)
  }

  const handleSaveProfile = async (event) => {
    event.preventDefault()
    setIsSavingProfile(true)
    setProfileError('')
    setProfileMessage('')
    try {
      const result = await apiRequest(endpoints.profile, {
        method: 'PUT',
        body: profileForm,
      })
      setProfile(result.perfil || { ...profile, ...profileForm })
      setProfileMessage(result.message || 'Perfil actualizado.')
    } catch (error) {
      setProfileError(error.message || 'No fue posible actualizar el perfil.')
    } finally {
      setIsSavingProfile(false)
    }
  }

  const handleDeleteOwnAdminAccount = async () => {
    if (!window.confirm('Se archivará tu historial como administrador, se enviará el resumen de saldos pendientes a tu correo y tu cuenta se eliminará inmediatamente. ¿Continuar?')) return
    const passwordActual = window.prompt('Confirma tu contraseña actual para eliminar tu cuenta:')
    if (passwordActual === null) return
    if (!passwordActual.trim()) {
      setProfileError('Debes confirmar tu contraseña actual.')
      return
    }
    setProfileError('')
    try {
      await apiRequest('/profile/mi-cuenta', {
        method: 'DELETE',
        body: { passwordActual },
      })
      setProfileOpen(false)
      handleLogout()
    } catch (error) {
      setProfileError(error.message || 'No fue posible eliminar tu cuenta.')
    }
  }

  const handleChangeProfilePassword = async (event) => {
    event.preventDefault()
    setPasswordError('')
    setPasswordMessage('')
    if (newProfilePassword !== confirmProfilePassword) {
      setPasswordError('La nueva contraseña y su confirmación no coinciden.')
      return
    }
    if (newProfilePassword.length < 8) {
      setPasswordError('La nueva contraseña debe tener al menos 8 caracteres.')
      return
    }

    setIsChangingProfilePassword(true)
    try {
      const result = await apiRequest(endpoints.changePassword, {
        method: 'POST',
        body: {
          passwordActual: currentProfilePassword,
          passwordNueva: newProfilePassword,
        },
      })
      setPasswordMessage(result.message || 'Contraseña actualizada.')
      setCurrentProfilePassword('')
      setNewProfilePassword('')
      setConfirmProfilePassword('')
      if (sessionStatus === 'must-change-password') {
        const currentProfile = await apiRequest(endpoints.profile)
        setProfile(currentProfile)
        setSessionStatus('authenticated')
      }
    } catch (error) {
      setPasswordError(error.message || 'No fue posible cambiar la contraseña.')
    } finally {
      setIsChangingProfilePassword(false)
    }
  }

  const handleRecoverySubmit = async (event) => {
    event.preventDefault()
    setAuthError('')
    setAuthNotice('')

    if (authMode === 'reset' && newPassword !== confirmNewPassword) {
      setAuthError('Las contraseñas no coinciden.')
      return
    }
    if (authMode === 'reset' && !/^\d{6}$/.test(recoveryCode.trim())) {
      setAuthError('Ingresa el código de 6 dígitos que recibiste por correo.')
      return
    }
    if (authMode === 'reset' && newPassword.length < 8) {
      setAuthError('La contraseña debe tener al menos 8 caracteres.')
      return
    }

    setIsLoggingIn(true)
    try {
      const correo = email.trim().toLowerCase()
      if (authMode === 'request-reset') {
        const result = await apiRequest(endpoints.requestPasswordReset, {
          method: 'POST',
          body: { correo },
        })
        setAuthMode('reset')
        setAuthNotice(result.message || 'Si el correo existe, recibirás un código de recuperación.')
      } else {
        const result = await apiRequest(endpoints.resetPassword, {
          method: 'POST',
          body: { correo, codigo: recoveryCode.trim(), nuevaPassword: newPassword },
        })
        setAuthMode('login')
        setPassword('')
        setRecoveryCode('')
        setNewPassword('')
        setConfirmNewPassword('')
        setAuthNotice(result.message || 'Contraseña actualizada. Ya puedes iniciar sesión.')
      }
    } catch (error) {
      setAuthError(error.message || 'No fue posible completar la recuperación.')
    } finally {
      setIsLoggingIn(false)
    }
  }
  const handleLogout = () => {
    clearToken()
    setProfile(null)
    setSectionData({})
    setSectionErrors({})
    setSessionStatus('signed-out')
    setAuthError('')
  }

  const handleRefresh = async () => {
    setIsRefreshing(true)
    try {
      const sections = activeSection === 'dashboard'
        ? Object.keys(resourceEndpointBySection)
        : [activeSection]
      await Promise.all(sections.map(loadSection))
    } finally {
      setIsRefreshing(false)
    }
  }

  const users = sectionData.usuarios || []
  const invoices = sectionData.facturas || []
  const payments = sectionData.pagos || []
  const cuts = sectionData.cortes || []
  const confirmedPayments = payments.filter((payment) => payment.confirmado)
  const pendingPayments = payments.filter((payment) => esPagoPendiente(payment))
  const inReportRange = (value) => {
    if (!value) return false
    const day = diaColombia(value)
    return (!reportFrom || day >= reportFrom) && (!reportTo || day <= reportTo)
  }
  // Un pago confirmado cuenta el día en que se confirmó (el dinero se recibió
  // ese día); uno sin confirmar, el día en que se inició.
  const reportPayments = payments.filter((payment) => inReportRange(fechaRecaudo(payment)))
  const reportInvoices = invoices.filter((invoice) => inReportRange(invoice.fecha_emision))
  const reportConfirmedPayments = reportPayments.filter((payment) => payment.confirmado)
  const reportPendingPayments = reportPayments.filter((payment) => esPagoPendiente(payment))
  const reportRevenue = reportConfirmedPayments.reduce((sum, payment) => sum + Number(payment.monto || 0), 0)
  const reportPendingRevenue = reportPendingPayments
    .reduce((sum, payment) => sum + Number(payment.monto || 0), 0)
  const activeUsers = users.filter((user) => user.activo)
  const pendingInvoices = invoices.filter((invoice) => invoice.estado === 'pendiente')
  const activeCuts = cuts.filter((cut) => cut.estado === 'activo')
  const metricValue = (section, value) => (
    sectionErrors[section] || sectionData[section] === undefined ? '—' : value
  )
  const dashboardKpis = [
    { id: 'usuarios', title: 'Usuarios activos', value: metricValue('usuarios', activeUsers.length), detail: 'Cuentas habilitadas', icon: UserRoundPlus, tone: 'blue' },
    { id: 'ingresos', title: 'Ingresos recibidos', value: metricValue('pagos', formatMoney(confirmedPayments.reduce((sum, payment) => sum + Number(payment.monto || 0), 0))), detail: 'Pagos confirmados', icon: CreditCard, tone: 'green' },
    { id: 'facturas', title: 'Facturas pendientes', value: metricValue('facturas', pendingInvoices.length), detail: 'Pendientes de pago', icon: FileText, tone: 'amber' },
    { id: 'cortes', title: 'Servicios suspendidos', value: metricValue('cortes', activeCuts.length), detail: 'Cortes activos', icon: AlertTriangle, tone: 'red' },
  ]
  const monthlyRevenue = new Map()
  confirmedPayments.forEach((payment) => {
    const day = diaColombia(fechaRecaudo(payment))
    if (!/^\d{4}-\d{2}/.test(day)) return
    const key = day.slice(0, 7)
    const current = monthlyRevenue.get(key) || {
      name: new Date(`${key}-15T12:00:00Z`).toLocaleDateString('es-CO', { month: 'short', timeZone: 'UTC' }),
      valor: 0,
    }
    current.valor += Number(payment.monto || 0)
    monthlyRevenue.set(key, current)
  })
  const revenueTrend = [...monthlyRevenue.entries()]
    .sort(([first], [second]) => first.localeCompare(second))
    .slice(-8)
    .map(([, item]) => item)
  const roleCounts = users.reduce((counts, user) => {
    const role = user.rol || 'sin rol'
    counts[role] = (counts[role] || 0) + 1
    return counts
  }, {})
  const serviceMix = Object.entries(roleCounts).map(([name, count]) => ({
    name,
    value: users.length ? Math.round((count / users.length) * 100) : 0,
    color: roleColors[name] || '#7a8cc3',
  }))
  const recentUsers = users.slice(0, 4).map((user) => ({
    name: [user.nombre, user.apellido].filter(Boolean).join(' ') || user.correo || 'Sin nombre',
    zone: user.zona || user.correo || 'Sin ubicación',
    status: user.activo ? 'Activo' : 'Inactivo',
    date: formatDate(user.created_at),
  }))
  const reportSummary = [
    { label: 'Usuarios registrados', value: metricValue('usuarios', users.length) },
    { label: 'Pagos que requieren acción', value: metricValue('pagos', payments.filter((payment) => requiereAccion(payment)).length) },
    { label: 'Cortes activos', value: metricValue('cortes', activeCuts.length) },
  ]
  const sectionTitles = {
    dashboard: 'HIDRO-APP',
    usuarios: 'Usuarios',
    eliminados: 'Perfiles eliminados',
    'paz-y-salvo': 'Paz y salvo',
    facturas: 'Facturación',
    pagos: 'Pagos',
    cortes: 'Cortes y reconexiones',
    notificaciones: 'Notificaciones',
    tarifas: 'Tarifas',
    reportes: 'Reportes',
  }
  const currentSectionTitle = sectionTitles[activeSection] || 'HIDRO-APP'

  if (sessionStatus === 'checking') {
    return <main className="auth-shell"><p className="auth-loading">Verificando sesión...</p></main>
  }

  if (sessionStatus === 'must-change-password') {
    return (
      <ForcedPasswordChange
        correo={profile?.correo}
        currentPassword={currentProfilePassword}
        setCurrentPassword={setCurrentProfilePassword}
        newPassword={newProfilePassword}
        setNewPassword={setNewProfilePassword}
        confirmPassword={confirmProfilePassword}
        setConfirmPassword={setConfirmProfilePassword}
        error={passwordError}
        isSaving={isChangingProfilePassword}
        onSubmit={handleChangeProfilePassword}
        onLogout={handleLogout}
      />
    )
  }

  if (sessionStatus !== 'authenticated') {
    return (
      <AuthScreen
        authMode={authMode}
        setAuthMode={setAuthMode}
        email={email}
        setEmail={setEmail}
        password={password}
        setPassword={setPassword}
        recoveryCode={recoveryCode}
        setRecoveryCode={setRecoveryCode}
        newPassword={newPassword}
        setNewPassword={setNewPassword}
        confirmNewPassword={confirmNewPassword}
        setConfirmNewPassword={setConfirmNewPassword}
        authNotice={authNotice}
        setAuthNotice={setAuthNotice}
        authError={authError}
        setAuthError={setAuthError}
        isLoggingIn={isLoggingIn}
        onLogin={handleLogin}
        onRecoverySubmit={handleRecoverySubmit}
      />
    )
  }
  const exportTreasuryWorkbook = async (report = 'todos') => {
    try {
      await exportTreasuryWorkbookFile({
        report,
        sectionData,
        users,
        invoices,
        reportPayments,
        reportInvoices,
        reportConfirmedPayments,
        reportPendingPayments,
        reportRevenue,
        reportPendingRevenue,
        reportFrom,
        reportTo,
        setActionError,
        setActionMessage,
      })
    } catch (error) {
      setActionMessage('')
      setActionError(error.message || 'No fue posible generar el informe Excel.')
    }
  }
  const sectionContext = {
    sectionData,
    sectionErrors,
    loadingSections,
    loadSection,
    filterRows,
    profile,
    endpoints,
    handleNavigate,
    openBulkUserImport,
    openCreateUser,
    openOperation,
    performAction,
    openInvoicePreview,
    exportTreasuryWorkbook,
    formatInvoiceNumber,
    formatMoney,
    formatDate,
    users,
    invoices,
    payments,
    confirmedPayments,
    activeUsers,
    activeCuts,
    reportPayments,
    reportInvoices,
    reportConfirmedPayments,
    reportPendingPayments,
    pendingPayments,
    reportRevenue,
    reportPendingRevenue,
    reportFrom,
    setReportFrom,
    reportTo,
    setReportTo,
    applyReportPreset,
    dashboardKpis,
    revenueTrend,
    serviceMix,
    recentUsers,
    reportSummary,
    metricValue,
  }
  return (
    <div className="app-shell">
      <Sidebar
        active={activeSection}
        onNavigate={handleNavigate}
        onLogout={handleLogout}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      <div className="page-shell">
        <header className="topbar">
          <div className="topbar-left">
            <button type="button" className="icon-button desktop-hidden" onClick={() => setSidebarOpen(true)}>
              <Menu size={18} />
            </button>
            <div>
              <p className="eyebrow">Panel administrativo · Acueducto Campo Amor</p>
              <h1>{currentSectionTitle}</h1>
            </div>
          </div>

          <div className="topbar-actions">
            <label className="search-box" aria-label="Buscar">
              <Search size={16} />
              <input type="search" placeholder="Buscar en la sección actual..." value={searchQuery} onChange={(event) => setSearchQuery(event.target.value)} />
            </label>
            <button type="button" className="icon-button" onClick={handleRefresh}>
              <ArrowUpRight size={18} className={isRefreshing ? 'spin' : ''} />
            </button>
            <button type="button" className="icon-button notice-button" onClick={() => handleNavigate('notificaciones')} aria-label="Ver notificaciones">
              <BellRing size={18} />
              <span className="notification-count">{(sectionData.notificaciones || []).filter((item) => item.estado === 'no_leido').length}</span>
            </button>
            <button type="button" className="profile-box profile-box-button" onClick={openProfile} aria-label="Editar perfil y contraseña">
              <div className="profile-avatar">{profile?.nombre?.charAt(0) || 'A'}</div>
              <div>
                <strong>{[profile?.nombre, profile?.apellido].filter(Boolean).join(' ') || 'Administrador'}</strong>
                <span>{profile?.correo}</span>
              </div>
            </button>
          </div>
        </header>

        <main className="content" aria-live="polite">
          <section className="hero-panel">
            <div>
              <p className="eyebrow">{activeSection === 'dashboard' ? 'Resumen operativo' : `Gestión de ${currentSectionTitle.toLocaleLowerCase('es')}`}</p>
              <h2>{activeSection === 'dashboard' ? 'Control central del acueducto' : currentSectionTitle}</h2>
            </div>
            <div className="hero-actions">
              {quickActions.map(({ label, section, icon: Icon }) => (
                <button key={label} type="button" className="secondary-button" onClick={() => handleNavigate(section)}>
                  <Icon size={16} />
                  {label}
                </button>
              ))}
            </div>
          </section>

          {actionMessage && <p className="action-feedback" role="status">{actionMessage}</p>}
          {actionError && <p className="auth-error" role="alert">{actionError}</p>}
          <SectionViews activeSection={activeSection} context={sectionContext} />
        </main>
      </div>
      {profileOpen && (
        <div className="modal-backdrop">
          <section className="modal-panel profile-modal-panel" role="dialog" aria-modal="true" aria-labelledby="profile-title">
            <div className="panel-header">
              <div>
                <p className="eyebrow">Cuenta de administrador</p>
                <h2 id="profile-title">Mi perfil</h2>
              </div>
              <button type="button" className="soft-button" onClick={() => setProfileOpen(false)}>Cerrar</button>
            </div>

            <form className="profile-form" onSubmit={handleSaveProfile}>
              <h3 className="form-section-title"><UserRound size={17} /> Datos personales</h3>
              <label>Nombre<input value={profileForm.nombre || ''} onChange={(event) => setProfileForm({ ...profileForm, nombre: event.target.value })} required /></label>
              <label>Apellido<input value={profileForm.apellido || ''} onChange={(event) => setProfileForm({ ...profileForm, apellido: event.target.value })} required /></label>
              <label className="form-wide">Correo electrónico<input value={profile?.correo || ''} readOnly /></label>
              <label>Teléfono<input type="tel" value={profileForm.telefono || ''} onChange={(event) => setProfileForm({ ...profileForm, telefono: event.target.value })} /></label>
              <label>Número de lote<input value={profileForm.numero_lote || ''} onChange={(event) => setProfileForm({ ...profileForm, numero_lote: event.target.value })} /></label>
              <label className="form-wide">Dirección<input value={profileForm.direccion || ''} onChange={(event) => setProfileForm({ ...profileForm, direccion: event.target.value })} /></label>
              <label>Ocupación<input value={profileForm.ocupacion || ''} onChange={(event) => setProfileForm({ ...profileForm, ocupacion: event.target.value })} /></label>
              <label>Zona<input value={profileForm.zona || ''} onChange={(event) => setProfileForm({ ...profileForm, zona: event.target.value })} /></label>
              {profileError && <p className="auth-error form-wide" role="alert">{profileError}</p>}
              {profileMessage && <p className="auth-notice form-wide" role="status">{profileMessage}</p>}
              <button type="submit" className="primary-button form-wide" disabled={isSavingProfile}>
                {isSavingProfile ? 'Guardando...' : 'Guardar perfil'}
              </button>
            </form>

            <form className="profile-form profile-password-form" onSubmit={handleChangeProfilePassword}>
              <h3 className="form-section-title"><KeyRound size={17} /> Cambiar contraseña</h3>
              <label className="form-wide">Contraseña actual
                <input type="password" autoComplete="current-password" value={currentProfilePassword} onChange={(event) => setCurrentProfilePassword(event.target.value)} required />
              </label>
              <label>Nueva contraseña
                <input type="password" autoComplete="new-password" minLength={8} value={newProfilePassword} onChange={(event) => setNewProfilePassword(event.target.value)} required />
              </label>
              <label>Confirmar contraseña
                <input type="password" autoComplete="new-password" minLength={8} value={confirmProfilePassword} onChange={(event) => setConfirmProfilePassword(event.target.value)} required />
              </label>
              <p className="form-hint form-wide">La contraseña debe tener al menos 8 caracteres.</p>
              {passwordError && <p className="auth-error form-wide" role="alert">{passwordError}</p>}
              {passwordMessage && <p className="auth-notice form-wide" role="status">{passwordMessage}</p>}
              <button type="submit" className="primary-button form-wide" disabled={isChangingProfilePassword}>
                {isChangingProfilePassword ? 'Actualizando...' : 'Cambiar contraseña'}
              </button>
            </form>

            <div className="profile-form">
              <button type="button" className="link-button danger-link" onClick={handleDeleteOwnAdminAccount}>
                Eliminar mi cuenta de administrador
              </button>
            </div>
          </section>
        </div>
      )}
      {createUserOpen && (
        <div className="modal-backdrop">
          <section className="modal-panel" role="dialog" aria-modal="true" aria-labelledby="create-user-title">
            <div className="panel-header">
              <div>
                <p className="eyebrow">Gestión de usuarios</p>
                <h2 id="create-user-title">Nuevo usuario</h2>
              </div>
              <button type="button" className="soft-button" onClick={() => setCreateUserOpen(false)}>Cerrar</button>
            </div>
            {createdTemporaryPassword ? (
              <div className="created-user-result" role="status">
                <CheckCircle2 size={22} />
                <div>
                  <strong>Usuario creado</strong>
                  <p>{createdUserEmailSent
                    ? 'Le enviamos un correo con cómo entrar: con un código a su correo (lo más fácil) o con esta contraseña temporal.'
                    : 'No se pudo enviar el correo. Comparte esta contraseña temporal, o dile que entre con "Entrar con un código a mi correo".'}</p>
                  <code>{createdTemporaryPassword}</code>
                </div>
              </div>
            ) : (
              <form className="create-user-form" onSubmit={handleCreateUser}>
                <label>Nombre<input value={newUser.nombre} onChange={(event) => setNewUser({ ...newUser, nombre: event.target.value })} required /></label>
                <label>Apellido<input value={newUser.apellido} onChange={(event) => setNewUser({ ...newUser, apellido: event.target.value })} required /></label>
                <label className="form-wide">Correo electrónico<input type="email" autoComplete="email" value={newUser.correo} onChange={(event) => setNewUser({ ...newUser, correo: event.target.value })} required /></label>
                <label className="form-wide">Cédula<input inputMode="numeric" pattern="[0-9. -]{5,20}" value={newUser.cedula} onChange={(event) => setNewUser({ ...newUser, cedula: event.target.value })} required /></label>
                <label className="form-wide">Rol
                  <select value={newUser.rol} onChange={(event) => setNewUser({ ...newUser, rol: event.target.value })}>
                    <option value="usuario">Usuario</option>
                    <option value="fontanero">Fontanero</option>
                    <option value="administrador">Administrador</option>
                  </select>
                </label>
                {/* Opcionales: registrar la ubicación aquí evita que el usuario tenga que hacerlo. */}
                <label>Teléfono<input type="tel" value={newUser.telefono} onChange={(event) => setNewUser({ ...newUser, telefono: event.target.value })} /></label>
                <label>Número de lote<input value={newUser.numero_lote} onChange={(event) => setNewUser({ ...newUser, numero_lote: event.target.value })} /></label>
                <label>Dirección<input value={newUser.direccion} onChange={(event) => setNewUser({ ...newUser, direccion: event.target.value })} /></label>
                <label>Zona<input value={newUser.zona} onChange={(event) => setNewUser({ ...newUser, zona: event.target.value })} /></label>
                {createUserError && <p className="auth-error form-wide" role="alert">{createUserError}</p>}
                <button type="submit" className="primary-button form-wide" disabled={isCreatingUser}>
                  {isCreatingUser ? 'Creando...' : 'Crear usuario'}
                </button>
              </form>
            )}
          </section>
        </div>
      )}
      {bulkUserOpen && (
        <div className="modal-backdrop">
          <section className="modal-panel bulk-modal-panel" role="dialog" aria-modal="true" aria-labelledby="bulk-users-title">
            <div className="panel-header">
              <div>
                <p className="eyebrow">Gestión de usuarios</p>
                <h2 id="bulk-users-title">Carga masiva de usuarios</h2>
              </div>
              <button type="button" className="soft-button" onClick={() => setBulkUserOpen(false)} disabled={isImportingUsers}>Cerrar</button>
            </div>
            <p className="bulk-help">
              Sube un archivo CSV UTF-8 o Excel (.xlsx) con las columnas <strong>nombre, apellido, correo</strong> y, opcionalmente, <strong>cédula y rol</strong>.
              Si omites el rol, se asignará “usuario”. Máximo {MAX_BULK_USERS} usuarios y 5 MB por archivo.
            </p>
            <div className="bulk-template-actions">
              <button type="button" className="link-button bulk-template-button" onClick={() => handleDownloadUsersTemplate('xlsx')}>
                <Download size={16} /> Descargar plantilla Excel (.xlsx)
              </button>
              <button type="button" className="link-button bulk-template-button" onClick={() => handleDownloadUsersTemplate('csv')}>
                <Download size={16} /> Plantilla CSV
              </button>
            </div>
            <form className="bulk-user-form" onSubmit={handleBulkUserImport}>
              <label className="bulk-file-input">
                Archivo CSV o Excel
                <input type="file" accept=".csv,.xlsx,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onChange={handleBulkFileChange} disabled={isImportingUsers} />
              </label>
              {bulkUserError && <p className="auth-error form-wide" role="alert">{bulkUserError}</p>}
              {bulkUsers.length > 0 && (
                <>
                  <p className="bulk-summary form-wide" role="status">
                    {bulkUsers.filter((user) => !user.error).length} válidos · {bulkUsers.filter((user) => user.error).length} con errores
                  </p>
                  {isImportingUsers && (
                    <p className="bulk-progress form-wide" role="status">
                      Procesando {bulkProgress.completed} de {bulkProgress.total} usuarios...
                    </p>
                  )}
                  {bulkUserResults.length > 0 && (
                    <>
                      {!isImportingUsers && (
                        <>
                          <p className="bulk-summary form-wide" role="status">
                            {bulkUserResults.filter((user) => ['success', 'warning'].includes(user.status)).length} cuentas creadas · {bulkUserResults.filter((user) => user.status === 'warning').length} con correo fallido · {bulkUserResults.filter((user) => user.status === 'error').length} con errores
                          </p>
                          {bulkUserResults.some((user) => user.status === 'error') && (
                            <button type="button" className="secondary-button form-wide" onClick={handleDownloadBulkErrors}>
                              <Download size={16} />
                              Descargar filas con errores (CSV)
                            </button>
                          )}
                        </>
                      )}
                      <div className="table-wrap bulk-results form-wide">
                        <table>
                          <thead>
                            <tr><th>Fila</th><th>Usuario</th><th>Correo</th><th>Resultado</th></tr>
                          </thead>
                          <tbody>
                            {bulkUserResults.map((user) => (
                              <tr key={user.line}>
                                <td>{user.line}</td>
                                <td>{[user.nombre, user.apellido].filter(Boolean).join(' ') || '—'}</td>
                                <td>{user.correo || '—'}</td>
                                <td className={user.status === 'success' ? 'bulk-success' : user.status === 'warning' ? 'bulk-warning' : user.status === 'error' ? 'error-text' : ''}>
                                  {user.message}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </>
                  )}
                </>
              )}
              <button
                type="submit"
                className="primary-button form-wide"
                disabled={isImportingUsers || bulkUserResults.length > 0 || !bulkUsers.some((user) => !user.error)}
              >
                {isImportingUsers ? 'Importando...' : bulkUserResults.length > 0 ? 'Importación finalizada' : `Crear ${bulkUsers.filter((user) => !user.error).length} usuarios`}
              </button>
            </form>
          </section>
        </div>
      )}
      {operationType && (
        <div className="modal-backdrop">
          <section className="modal-panel" role="dialog" aria-modal="true" aria-labelledby="operation-title">
            <div className="panel-header">
              <div>
                <p className="eyebrow">Administración</p>
                <h2 id="operation-title">{operationDefinitions[operationType].title}</h2>
              </div>
              <button type="button" className="soft-button" onClick={() => setOperationType('')}>Cerrar</button>
            </div>
            <form className="create-user-form" onSubmit={handleOperationSubmit}>
              {operationDefinitions[operationType].fields.map((field) => (
                <label key={field.name} className={field.type === 'textarea' || field.type === 'checkbox' ? 'form-wide' : ''}>
                  {field.label}
                  {field.type === 'checkbox' ? (
                    <input type="checkbox" checked={Boolean(operationForm[field.name])} onChange={(event) => setOperationForm({ ...operationForm, [field.name]: event.target.checked })} />
                  ) : field.type === 'textarea' ? (
                    <textarea value={operationForm[field.name] ?? ''} onChange={(event) => setOperationForm({ ...operationForm, [field.name]: event.target.value })} required={field.required} rows={4} />
                  ) : field.type === 'user' || field.type === 'recipient' ? (
                    <select value={operationForm[field.name] ?? ''} onChange={(event) => setOperationForm({ ...operationForm, [field.name]: event.target.value })} required={field.required}>
                      {field.type === 'recipient' && <option value="todos">{operationType === 'notificacion' ? 'Todos los usuarios registrados' : 'Todos los usuarios activos'}</option>}
                      {field.type === 'user' && <option value="">Selecciona un usuario</option>}
                      {users.filter((user) => field.type !== 'recipient' || operationType !== 'facturaExtraordinaria' || (user.rol === 'usuario' && user.activo)).map((user) => <option key={user.id} value={user.id}>{[user.nombre, user.apellido].filter(Boolean).join(' ')} - {user.correo} ({user.rol})</option>)}
                    </select>
                  ) : field.type === 'select' ? (
                    <select value={operationForm[field.name] ?? ''} onChange={(event) => setOperationForm({ ...operationForm, [field.name]: event.target.value })} required={field.required}>
                      {field.options.map((option) => <option key={option} value={option}>{option}</option>)}
                    </select>
                  ) : field.type === 'zona' ? (
                    <select value={operationForm[field.name] ?? ''} onChange={(event) => setOperationForm({ ...operationForm, [field.name]: event.target.value })}>
                      <option value="">Todo el acueducto</option>
                      {zones.map((zona) => <option key={zona} value={zona}>{zona}</option>)}
                    </select>
                  ) : (
                    <input type={field.type || 'text'} inputMode={field.name === 'cedula' ? 'numeric' : undefined} pattern={field.name === 'cedula' ? '[0-9]{5,15}' : undefined} minLength={field.name === 'cedula' ? 5 : undefined} maxLength={field.name === 'cedula' ? 15 : undefined} min={field.type === 'number' ? '0' : undefined} step={field.type === 'number' ? 'any' : undefined} value={operationForm[field.name] ?? ''} onChange={(event) => setOperationForm({ ...operationForm, [field.name]: field.name === 'cedula' ? event.target.value.replace(/\D/g, '').slice(0, 15) : event.target.value })} required={field.required} />
                  )}
                </label>
              ))}
              {operationError && <p className="auth-error form-wide" role="alert">{operationError}</p>}
              <button type="submit" className="primary-button form-wide" disabled={operationPending}>
                {operationPending
                  ? operationType === 'facturacionMensual' ? 'Generando...' : 'Guardando...'
                  : operationDefinitions[operationType].submitLabel || (operationType === 'facturacionMensual' ? 'Generar facturas' : 'Guardar')}
              </button>
            </form>
          </section>
        </div>
      )}
      {invoicePreview && (() => {
        const invoiceUser = users.find((user) => user.id === invoicePreview.perfil_id)
        const invoiceUserName = [invoiceUser?.nombre, invoiceUser?.apellido].filter(Boolean).join(' ') || 'Suscriptor'
        return (
          <div className="modal-backdrop">
            <section className="modal-panel invoice-modal-panel" role="dialog" aria-modal="true" aria-labelledby="invoice-preview-title">
              <div className="panel-header invoice-preview-actions">
                <div>
                  <p className="eyebrow">Documento de cobro</p>
                  <h2 id="invoice-preview-title">Vista previa de factura</h2>
                </div>
                <div className="hero-actions">
                  <button type="button" className="primary-button invoice-download-button" onClick={handleDownloadInvoice}><Printer size={16} />Descargar PDF</button>
                  <button type="button" className="soft-button invoice-close-button" onClick={() => setInvoicePreview(null)}>Cerrar</button>
                </div>
              </div>
              <article className="invoice-sheet" id="invoice-document">
                <div className="invoice-watermark" aria-hidden="true">
                  <img src={hidroAppLogo} alt="" />
                </div>
                <header className="invoice-heading">
                  <div className="invoice-heading-brand">
                    <span className="invoice-logo-frame"><img className="invoice-logo" src={hidroAppLogo} alt="" /></span>
                    <div>
                      <span className="invoice-brand">HidroApp · Acueducto Campo Amor</span>
                      <h2>{invoicePreview.tipo === 'extraordinaria'
                        ? 'Factura extraordinaria'
                        : Number(invoicePreview.meses_cubiertos) > 1
                          ? `Factura de servicio · ${Number(invoicePreview.meses_cubiertos)} meses`
                          : 'Factura de servicio'}</h2>
                    </div>
                  </div>
                  <div className="invoice-number">
                    <span>Factura</span>
                    <strong>{formatInvoiceNumber(invoicePreview)}</strong>
                  </div>
                </header>
                <div className="invoice-meta">
                  <div><span>Periodo facturado</span><strong>{Number(invoicePreview.meses_cubiertos) > 1
                    ? `${invoicePreview.periodo_inicio || invoicePreview.periodo} a ${invoicePreview.periodo_fin}`
                    : invoicePreview.periodo || '—'}</strong></div>
                  {invoicePreview.fecha_proxima_facturacion && (
                    <div><span>Próxima facturación</span><strong>{formatDate(invoicePreview.fecha_proxima_facturacion)}</strong></div>
                  )}
                  <div><span>Estado</span><strong>{invoicePreview.estado || '—'}</strong></div>
                  <div><span>Fecha de emisión</span><strong>{formatDate(invoicePreview.fecha_emision)}</strong></div>
                  <div><span>Fecha límite de pago</span><strong>{formatDate(invoicePreview.fecha_vencimiento)}</strong></div>
                </div>
                <div className="invoice-party">
                  <span>Suscriptor</span>
                  <strong>{invoiceUserName}</strong>
                  <p>{invoiceUser?.correo || 'Correo no registrado'}</p>
                  {invoiceUser?.direccion && <p>{invoiceUser.direccion}</p>}
                  {invoiceUser?.zona && <p>Zona {invoiceUser.zona}</p>}
                  {invoiceUser?.numero_lote && <p>Lote {invoiceUser.numero_lote}</p>}
                </div>
                <table className="invoice-lines">
                  <thead><tr><th>Concepto</th><th>Periodo</th><th>Valor</th></tr></thead>
                  <tbody><tr>
                    <td>{invoicePreview.observacion || invoicePreview.detalle_prepago || (invoicePreview.tipo === 'extraordinaria' ? 'Cuota extraordinaria' : 'Servicio de acueducto')}</td>
                    <td>{Number(invoicePreview.meses_cubiertos) > 1
                      ? `${invoicePreview.periodo_inicio || invoicePreview.periodo} a ${invoicePreview.periodo_fin}`
                      : invoicePreview.periodo || '—'}</td>
                    <td>{formatMoney(invoicePreview.valor_total)}</td>
                  </tr></tbody>
                </table>
                <div className="invoice-total"><span>Total a pagar</span><strong>{formatMoney(invoicePreview.valor_total)}</strong></div>
                <p className="invoice-note">Conserve este documento como soporte de su facturación.</p>
              </article>
            </section>
          </div>
        )
      })()}
    </div>
  )
}

export default App
