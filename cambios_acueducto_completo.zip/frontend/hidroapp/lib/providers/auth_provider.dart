import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';

import '../models/profile.dart';
import '../services/api_service.dart';

enum AuthStatus { unknown, authenticated, unauthenticated }

abstract interface class AuthSessionStorage {
  Future<String?> read(String key);
  Future<void> write(String key, String value);
  Future<void> delete(String key);
}

class FlutterAuthSessionStorage implements AuthSessionStorage {
  FlutterAuthSessionStorage([FlutterSecureStorage? storage])
    : _storage = storage ?? const FlutterSecureStorage();

  final FlutterSecureStorage _storage;

  @override
  Future<String?> read(String key) => _storage.read(key: key);

  @override
  Future<void> write(String key, String value) =>
      _storage.write(key: key, value: value);

  @override
  Future<void> delete(String key) => _storage.delete(key: key);
}

/// Maneja la sesión del usuario: token de Supabase, perfil y llamadas de auth.
class AuthProvider extends ChangeNotifier {
  AuthProvider({
    ApiService? api,
    AuthSessionStorage? storage,
    LocalAuthentication? localAuth,
  }) : _api = api ?? ApiService(),
       _storage = storage ?? FlutterAuthSessionStorage(),
       _localAuth = localAuth ?? LocalAuthentication() {
    _api.onUnauthorized = _renovarSesion;
  }

  final ApiService _api;
  final AuthSessionStorage _storage;

  static const _tokenKey = 'access_token';
  // Se conserva el nombre histórico de la clave para no perder las sesiones
  // ya guardadas; hoy guarda el refresh token de cualquier sesión.
  static const _refreshTokenKey = 'biometric_refresh_token';
  static const _legacyRefreshTokenKey = 'refresh_token';
  static const _biometricEnabledKey = 'biometric_enabled';

  AuthStatus _status = AuthStatus.unknown;
  Profile? _profile;

  AuthStatus get status => _status;
  Profile? get profile => _profile;
  ApiService get api => _api;
  bool get biometricEnabled => _biometricEnabled;
  bool _biometricEnabled = false;
  final LocalAuthentication _localAuth;

  /// Renovación del access token en curso, compartida por todas las
  /// peticiones que reciban 401 a la vez (el refresh token es de un solo uso).
  Future<bool>? _renovacionEnCurso;

  bool _biometriaAlIniciar = false;

  /// Devuelve `true` una sola vez tras abrir la app con biometría activa, para
  /// que el login lance la huella automáticamente sin esperar a que se toque
  /// el botón. Tras un cierre de sesión manual ya no se lanza sola.
  bool tomarBiometriaAlIniciar() {
    final pendiente = _biometriaAlIniciar;
    _biometriaAlIniciar = false;
    return pendiente && _biometricEnabled;
  }

  /// `true` cuando la cuenta tiene pendiente cambiar una contraseña temporal
  /// (generada por un administrador al crearla). Mientras sea `true`,
  /// [AuthGate] debe mostrar la pantalla de cambio obligatorio en vez de la
  /// app normal.
  bool get debeCambiarPassword => _profile?.debeCambiarPassword ?? false;

  /// Se llama al arrancar la app: intenta restaurar la sesión guardada.
  Future<void> bootstrap() async {
    _biometricEnabled = await _storage.read(_biometricEnabledKey) == 'true';
    if (_biometricEnabled) {
      // Si el usuario eligió biometría, cada apertura de la app pide su
      // confirmación antes de restaurar la sesión guardada.
      await _storage.delete(_tokenKey);
      _api.authToken = null;
      _biometriaAlIniciar = true;
      _setStatus(AuthStatus.unauthenticated);
      return;
    }
    notifyListeners();
    final token = await _storage.read(_tokenKey);
    if (token == null || token.isEmpty) {
      _setStatus(AuthStatus.unauthenticated);
      return;
    }

    _api.authToken = token;
    try {
      await _loadProfile();
      _setStatus(AuthStatus.authenticated);
    } on ApiException catch (e) {
      // Solo borramos la sesión guardada si el propio servidor la rechazó
      // (token inválido o expirado). Un error de red/timeout no debe forzar
      // un nuevo login: seguimos mostrando la pantalla de acceso, pero el
      // usuario podrá reintentar sin perder el token guardado.
      if (e.statusCode == 401 || e.statusCode == 403) {
        await _clear(preserveBiometric: _biometricEnabled);
      } else {
        _api.authToken = null;
      }
      _setStatus(AuthStatus.unauthenticated);
    } catch (_) {
      _api.authToken = null;
      _setStatus(AuthStatus.unauthenticated);
    }
  }

  Future<void> login(
    String identificador,
    String password, {
    bool conCedula = false,
  }) async {
    final data = await _api.post(
      '/auth/login',
      body: {
        if (conCedula)
          'cedula': identificador.replaceAll(RegExp(r'\D'), '')
        else
          'correo': identificador.trim(),
        'password': password,
      },
    );
    await _abrirSesion(data);
  }

  /// Pide al backend que envíe un código de acceso de 6 dígitos al correo.
  /// La respuesta es la misma exista o no la cuenta.
  Future<void> solicitarCodigoAcceso(String correo) async {
    await _api.post(
      '/auth/codigo-acceso',
      body: {'correo': correo.trim().toLowerCase()},
    );
  }

  /// Entra sin contraseña con el código que llegó al correo.
  Future<void> loginConCodigo(String correo, String codigo) async {
    final data = await _api.post(
      '/auth/ingresar-con-codigo',
      body: {'correo': correo.trim().toLowerCase(), 'codigo': codigo.trim()},
    );
    await _abrirSesion(data);
  }

  /// Guarda la sesión que devolvió el backend (login con contraseña o con
  /// código) y carga el perfil.
  Future<void> _abrirSesion(dynamic data) async {
    String? token;
    try {
      if (data is Map && data['session'] is Map) {
        final accessToken = (data['session'] as Map)['access_token'];
        if (accessToken is String) token = accessToken;
      }
    } catch (_) {
      token = null;
    }
    if (token == null || token.isEmpty) {
      throw ApiException(
        'La respuesta del servidor no incluyó una sesión válida.',
      );
    }

    await _storage.write(_tokenKey, token);
    final refreshToken = (data['session'] as Map)['refresh_token'];
    if (refreshToken is String && refreshToken.isNotEmpty) {
      await _storage.write(_refreshTokenKey, refreshToken);
      await _storage.delete(_legacyRefreshTokenKey);
    } else {
      await _storage.delete(_refreshTokenKey);
      await _storage.delete(_legacyRefreshTokenKey);
    }
    _api.authToken = token;
    await _loadProfile();
    _setStatus(AuthStatus.authenticated);
  }

  Future<bool> deviceSupportsBiometrics() async {
    try {
      return await _localAuth.isDeviceSupported() &&
          (await _localAuth.getAvailableBiometrics()).isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  /// Activa o desactiva el ingreso con huella o rostro desde Ajustes.
  /// Al activarlo se pide la biometría una vez para confirmar que el dueño
  /// del dispositivo es quien lo hace. Devuelve `false` si la cancela.
  Future<bool> setBiometricEnabled(bool enabled) async {
    if (enabled) {
      final supported = await deviceSupportsBiometrics();
      if (!supported) {
        throw ApiException(
          'Este dispositivo no tiene huella ni rostro configurados.',
        );
      }
      final refreshToken =
          await _storage.read(_refreshTokenKey) ??
          await _storage.read(_legacyRefreshTokenKey);
      if (refreshToken == null || refreshToken.isEmpty) {
        throw ApiException(
          'Cierra sesión y vuelve a ingresar con tu contraseña para activarlo.',
        );
      }
      final confirmado = await _localAuth.authenticate(
        localizedReason: 'Confirma para activar el ingreso con huella o rostro',
        options: const AuthenticationOptions(biometricOnly: true),
      );
      if (!confirmado) return false;
      await _storage.write(_biometricEnabledKey, 'true');
    } else {
      // El refresh token se conserva: la app lo usa para renovar la sesión
      // en silencio aunque no haya biometría.
      await _storage.delete(_biometricEnabledKey);
    }
    _biometricEnabled = enabled;
    notifyListeners();
    return true;
  }

  Future<void> loginWithBiometrics() async {
    if (!_biometricEnabled) {
      throw ApiException('El acceso biométrico está desactivado.');
    }
    final refreshToken =
        await _storage.read(_refreshTokenKey) ??
        await _storage.read(_legacyRefreshTokenKey);
    if (refreshToken == null || refreshToken.isEmpty) {
      throw ApiException(
        'Ingresa con tu correo y contraseña para volver a habilitar la biometría.',
      );
    }
    final ok = await _localAuth.authenticate(
      localizedReason: 'Confirma tu identidad para ingresar a HIDROAPP',
      options: const AuthenticationOptions(biometricOnly: true),
    );
    if (!ok) return;
    await _pedirNuevaSesion(refreshToken);
    await _loadProfile();
    _setStatus(AuthStatus.authenticated);
  }

  Future<String?> _leerRefreshToken() async =>
      await _storage.read(_refreshTokenKey) ??
      await _storage.read(_legacyRefreshTokenKey);

  /// Cambia el refresh token por una sesión nueva y la guarda. Supabase rota
  /// el refresh token en cada uso, así que siempre guardamos el nuevo: si se
  /// conservara el viejo, la siguiente renovación fallaría.
  Future<void> _pedirNuevaSesion(String refreshToken) async {
    final data = await _api.renewSession(refreshToken);
    if (data is! Map || data['session'] is! Map) {
      throw ApiException(
        'No se pudo renovar la sesión. Ingresa con tu contraseña.',
      );
    }
    final session = data['session'] as Map;
    final token = session['access_token'];
    final nuevoRefresh = session['refresh_token'];
    if (token is! String || token.isEmpty) {
      throw ApiException('La sesión recibida no es válida.');
    }
    await _storage.write(_tokenKey, token);
    if (nuevoRefresh is String && nuevoRefresh.isNotEmpty) {
      await _storage.write(_refreshTokenKey, nuevoRefresh);
      await _storage.delete(_legacyRefreshTokenKey);
    }
    _api.authToken = token;
  }

  /// Renueva en silencio el access token vencido (dura ≈1 h) para que la
  /// sesión no se cierre mientras se usa la app. Lo invoca [ApiService] al
  /// recibir un 401; si no se puede renovar, cierra la sesión y vuelve a la
  /// pantalla de acceso en vez de dejar al usuario viendo un error suelto.
  Future<bool> _renovarSesion() => _renovacionEnCurso ??= _intentarRenovar()
      .whenComplete(() => _renovacionEnCurso = null);

  Future<bool> _intentarRenovar() async {
    final refreshToken = await _leerRefreshToken();
    if (refreshToken == null || refreshToken.isEmpty) {
      await _sesionExpirada(conservarRefresh: false);
      return false;
    }
    try {
      await _pedirNuevaSesion(refreshToken);
      return true;
    } catch (error) {
      final statusCode = error is ApiException ? error.statusCode : null;
      // Ante una falla temporal (red, servidor caído, límite de peticiones)
      // se conserva el refresh token para poder reintentar luego.
      final temporal =
          statusCode == null ||
          statusCode >= 500 ||
          statusCode == 408 ||
          statusCode == 429;
      await _sesionExpirada(conservarRefresh: temporal);
      return false;
    }
  }

  Future<void> _sesionExpirada({required bool conservarRefresh}) async {
    if (conservarRefresh) {
      await _storage.delete(_tokenKey);
      _api.authToken = null;
      _profile = null;
    } else {
      await _clear();
    }
    if (_status == AuthStatus.authenticated) {
      _setStatus(AuthStatus.unauthenticated);
    }
  }

  // No hay auto-registro: las cuentas las crea el administrador del acueducto.

  /// Confirma el código de 6 dígitos que se envió por correo al crear la cuenta.
  /// Si el código es correcto, deja iniciada la sesión con [password].
  Future<void> verificarCuenta(
    String correo,
    String codigo,
    String password,
  ) async {
    await _api.post(
      '/auth/verificar',
      body: {'correo': correo.trim(), 'codigo': codigo.trim()},
    );
    await login(correo, password);
  }

  /// Pide al backend que reenvíe el código de verificación a [correo].
  Future<void> reenviarCodigoVerificacion(String correo) async {
    await _api.post('/auth/reenviar-codigo', body: {'correo': correo.trim()});
  }

  /// Pide al backend que envíe un código de recuperación de contraseña al
  /// correo. Por seguridad responde igual exista o no la cuenta.
  Future<void> solicitarRecuperacion(String correo) async {
    await _api.post(
      '/auth/solicitar-recuperacion',
      body: {'correo': correo.trim()},
    );
  }

  /// Restablece la contraseña (sin sesión) con el código recibido por correo.
  Future<void> resetearPassword(
    String correo,
    String codigo,
    String nuevaPassword,
  ) async {
    await _api.post(
      '/auth/resetear-password',
      body: {
        'correo': correo.trim(),
        'codigo': codigo.trim(),
        'nuevaPassword': nuevaPassword,
      },
    );
  }

  /// Cambia la contraseña de la cuenta ya autenticada. Se usa para el cambio
  /// obligatorio tras el primer login con una contraseña temporal, pero sirve
  /// igual para un cambio voluntario. Al terminar, refresca el perfil para
  /// que [debeCambiarPassword] pase a `false` y [AuthGate] deje entrar a la app.
  Future<void> cambiarPassword(
    String passwordActual,
    String passwordNueva,
  ) async {
    await _api.post(
      '/auth/cambiar-password',
      body: {'passwordActual': passwordActual, 'passwordNueva': passwordNueva},
    );
    await _loadProfile();
    notifyListeners();
  }

  /// Vuelve a pedir el perfil al backend (p. ej. tras editarlo) y notifica a
  /// quien esté escuchando (como [PerfilScreen]).
  Future<void> refreshProfile() async {
    await _loadProfile();
    notifyListeners();
  }

  Future<void> logout() async {
    await _clear(preserveBiometric: _biometricEnabled);
    _setStatus(AuthStatus.unauthenticated);
  }

  Future<void> eliminarCuenta({
    required String passwordActual,
    String? nota,
  }) async {
    await _api.delete(
      '/profile/mi-cuenta',
      body: {
        'passwordActual': passwordActual,
        if (nota != null && nota.trim().isNotEmpty) 'nota': nota.trim(),
      },
    );
    await _clear();
    _setStatus(AuthStatus.unauthenticated);
  }

  Future<void> _loadProfile() async {
    final data = await _api.get('/profile/mi-perfil');
    if (data is Map<String, dynamic>) {
      _profile = Profile.fromJson(data);
    }
  }

  Future<void> _clear({bool preserveBiometric = false}) async {
    await _storage.delete(_tokenKey);
    if (!preserveBiometric) {
      await _storage.delete(_refreshTokenKey);
      await _storage.delete(_legacyRefreshTokenKey);
      await _storage.delete(_biometricEnabledKey);
      _biometricEnabled = false;
    }
    _api.authToken = null;
    _profile = null;
  }

  void _setStatus(AuthStatus status) {
    _status = status;
    notifyListeners();
  }

  /// Renueva la sesión después de un 401. ApiService repite la petición con
  /// el token nuevo; varias peticiones concurrentes comparten esta renovación.
  @override
  void dispose() {
    _api.dispose();
    super.dispose();
  }
}
